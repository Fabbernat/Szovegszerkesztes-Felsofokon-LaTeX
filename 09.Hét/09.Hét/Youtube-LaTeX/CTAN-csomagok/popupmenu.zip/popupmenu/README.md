The popupmenu Package
Dated: 2020-07-26

popupmenu is a LaTeX package used to create a menu structure. This
menu structure (an array of menu items) is passed to the Acrobat
JavaScript method app.popUpMenuEx() method to create a popup menu.
Using the environments defined in this package, and the command
\popUpMenu, you can create and display hierarchical menus. 

Workflows supported: pdflatex, lualatex, xelatex, 
dvips-><distiller|ps2pdf>. 

What's New 2020-07-26: Defined the tracking option and the 
\puProcessMenu command to track menu selections. Other 
improvements and bug fixes were made. 

D. P. Story
2020-07-29
