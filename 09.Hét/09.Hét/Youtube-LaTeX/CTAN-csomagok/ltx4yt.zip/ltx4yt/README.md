The ltx4yt package
Dated: 2021-06-08

What ltx4yt does is to provide some tools for creating links, dropdown lists, 
popup menus for playing selected YouTube videos in the default browser. Perfect 
for personal use and for academic, professional, or classroom presentations 
that refer to YouTube content. 

All workflows are supported: pdflatex, lualatex, xelatex, dvips->distiller, 
and dvips->ps2pdf. In the latter case, the document should not use any 
document JavaScripts. 

This package replaces yt4pdf, which is withdrawn from CTAN. 

Now, I simply must get back to my retirement.

What's New (2021-06-08) Rewrote commands and examples to reflect a new method 
  of doing YouTube searches. 

Dr. D. P. Story
www.acrotex.net
dpstory@uakron.edu
dpstory@acrotex.net
